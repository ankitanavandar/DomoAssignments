import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

/**
 * 
 */

/**
 * @author ankita_navandar
 *
 */
public class GetExample {
	private static JSONObject jsonObject;
	private static String result;
	OkHttpClient client = new OkHttpClient();

	String run(String url) throws IOException {
	Request request = new Request.Builder()
	    .url(url)
	    .build();

	Response result = client.newCall(request).execute();
	return result.body().string();
	}

	public static void main(String[] args) throws IOException {
		
	GetExample example = new GetExample();
	String response = example.run("http://dummy.restapiexample.com/api/v1/employees");
	//System.out.print(result);
	
	result = "";
	
	try {
		JSONParser jsonParser = new JSONParser();
		Object object = jsonParser.parse(response);
		jsonObject = (JSONObject)object;
		parseJson(jsonObject);
		System.out.print(result);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	String content = result;
    String path = "D:\\Ankita\\Assignment-5\\output.txt";
    
    try(FileWriter writer = new FileWriter(new File("D:\\Ankita\\Assignment-5\\output.txt"));
			BufferedWriter bw = new BufferedWriter(writer)){
		bw.write(content);
	}
	catch(IOException e)
	{
		e.printStackTrace();
	}
    
}

	private static String parseJson(JSONObject jsonObject) throws ParseException{
		Set<Object> set = jsonObject.keySet();
		//String result = "";
		Iterator<Object> iterator = set.iterator();
		while(iterator.hasNext())
		{
			Object obj = iterator.next();
			if(jsonObject.get(obj) instanceof JSONArray)
			{
				//System.out.println(obj.toString());
				getArray(jsonObject.get(obj));
			}else{
				if(jsonObject.get(obj) instanceof JSONObject)
				{
					parseJson((JSONObject)jsonObject.get(obj));
				}else{
					//System.out.print(obj.toString()+"="+jsonObject.get(obj)+" ");
					result = result + obj.toString()+" = "+jsonObject.get(obj)+" ";
				}
			}
		}
		result = result + "\n";
		
		
		return result;
		// TODO Auto-generated method stub
		
	}

	public static void getArray(Object object2)throws ParseException {
		// TODO Auto-generated method stub
		JSONArray jsonArr = (JSONArray)object2;
		for(int k=0;k<jsonArr.size();k++)
		{
			if(jsonArr.get(k) instanceof JSONObject){
				parseJson((JSONObject) jsonArr.get(k));
				}
			else{
				System.out.println(jsonArr.get(k));
			}
		}
	}
}
