/**
 * 
 */

/**
 * @author ankita_navandar
 *
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class FileRead {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File obj = new File("users.json");
			Scanner reader = new Scanner(obj);
			while(reader.hasNextLine())
			{
				String data = reader.nextLine();
				System.out.println(data);
			}
			reader.close();
		} catch (FileNotFoundException e) {
			System.out.println("An error occured");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
