import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * 
 */
/**
 * @author ankita_navandar
 *
 */
public class MapExample 
{
	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		//Creating Map
		Map map = new HashMap();
		
		//Adding object in HashMap
		map.put(1,"Ankita");  
		map.put(2,"Bipika");  
		map.put(3,"Supriya");  
		map.put(4,"Parul"); 
		
		//Print map
		System.out.println(map);
		
		//Traversing map through Iterator
		
		//Need to convert map to set in order to traverse
		Set set=map.entrySet();
		
		Iterator itr=set.iterator();  
		
	    while(itr.hasNext())
	    {  
	        //Converting to Map.Entry so that we can get key and value separately 
	    	
	        Map.Entry entry=(Map.Entry)itr.next();  
	        System.out.println(entry.getKey()+" "+entry.getValue());  
	    }  
	    
	    System.out.println(" ");
	    
	    //removing object from map
	    map.remove(3);
	    
	    //Print map - After removing object
	    System.out.println(map);
	    
	    //Traversing map through Iterator
	    Set set1=map.entrySet();
		
		Iterator itr1=set1.iterator();  
		
	    while(itr1.hasNext())
	    {  
	        //Converting to Map.Entry so that we can get key and value separately 
	    	
	        Map.Entry entry=(Map.Entry)itr1.next();  
	        System.out.println(entry.getKey()+" "+entry.getValue());  
	    } 
	}
}