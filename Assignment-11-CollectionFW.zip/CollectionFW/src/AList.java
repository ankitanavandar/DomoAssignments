import java.util.ArrayList;
import java.util.Iterator;

/**
 * 
 */
/**
 * @author ankita_navandar
 *
 */
public class AList 
{
	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		//Creating arraylist 
		ArrayList<String> list=new ArrayList<String>();
		
		//Adding object in arraylist
		list.add("Ankita");  
		list.add("Bipika");  
		list.add("Supriya");  
		list.add("Parul"); 
		
		//Print list
		System.out.println(list);
		
		//Traversing list through Iterator  
		Iterator itr=list.iterator(); 
		
		while(itr.hasNext())
		{  
			System.out.println(itr.next()+" ");  
		}  
		
		System.out.println(" ");

		//Removing object from arrayList
		list.remove(2);
		
		//Print list - After removing object
		System.out.println(list);
		
		System.out.println(" ");
		
		//Removing object from list
        list.remove("Ankita");
        System.out.println("Set after removing object = "+list);
        
        System.out.println(" ");
        
        //Print element at index 1
        System.out.println("Element at index 1 = "+list.get(1)); 
        
        System.out.println(" ");
        
        //Replace element at index 1
        list.set(1,"Shital");
        System.out.println("Replace Parul with Shital ="+list);
	}
}
