import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

/**
 * 
 */
/**
 * @author ankita_navandar
 *
 */
public class SetExample 
{
	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		//Creating Set
		Set<String> set = new HashSet();
		
		//Adding objects in set
		set.add("This");
		set.add("is");
		set.add("set");
		set.add("example");
		
		//Print set
		System.out.println("Initial set = "+set);
		
		//Traversing set through iterator
		Iterator<String> itr =set.iterator();  
        while(itr.hasNext())  
        {  
        	System.out.println(itr.next());  
        }
        
        System.out.println(" ");
        
        //Removing object from set
        set.remove("is");
        
        //Print set after removing object
        System.out.println("Set after removing object = "+set);
        
      	System.out.println(" ");
      	
      	//Checks for a specific object in set
      	System.out.println("set conatins word this = "+set.contains("This"));
      	
      	System.out.println(" ");
      	
      	//Check if set is empty
      	System.out.println("Set Empty = "+set.isEmpty());
      	
      	System.out.println(" ");
      	
      	//Size of set
      	System.out.println("Size of = "+set.size());
      	
      	System.out.println(" ");
      	
      	//Clear all set objects
      	set.clear();
      	System.out.println("Set after clear operation = "+set);
	}
}
