package Test;

import org.testng.annotations.Test;

public class Add {
  @Test
  public void addition() {
	  int a = 2 + 4;
	  System.out.println("a");
	  assert a == 6;
	  System.out.println("Addition is 6");
  }
}
