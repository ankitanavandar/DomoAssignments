package Test;

import org.testng.annotations.Test;

public class StrLength {
  @Test
  public void LenCheck() {
	  int lnt = "JAVA".length();
	  assert lnt == 4;
	  System.out.println("Length is 4");
  }
}
