package Test;

import org.testng.annotations.Test;

public class StartWith {
  @Test
  public void start() {
	  String str = "Java";
	  assert(str.startsWith("J"));
	  System.out.println("Java starts with J check successful");
  }
}
