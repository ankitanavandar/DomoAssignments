package Test;

import org.testng.annotations.Test;

public class NewTest1 {
  @Test
  public void TestMethod() {
	  System.out.println("Welcome to TestNG");
  }
}
